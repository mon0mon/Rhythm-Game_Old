﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneManager : MonoBehaviour
{
    private static SceneManager instance = null;
    private static string str;

    public static SceneList SceneList;
    public SceneList scene;

    // Start is called before the first frame update
    void Start()
    {
        Initialize();
    }

    private void Initialize()
    {
        if (instance != null)
        {
            DestroyImmediate(gameObject);
            return;
        }

        instance = this;

        SceneList = scene;
    }

    public static SceneManager Instance => instance;

    public void LoadingScene()
    {
        switch (SceneList)
        {
            case SceneList.Loading_Scene:
                str = "Scenes/Loading_Scene";
                break;
            case SceneList.TouchSwipe_Test_Mobile:
                str = "Scenes/TouchSwipe_Test_Mobile";
                break;
            case SceneList.RhythmGame_Test_PC:
                str = "Scenes/RhythmGame_Test_PC";
                break;
        }
        UnityEngine.SceneManagement.SceneManager.LoadScene(str);
    }
}

public enum SceneList
{
    Loading_Scene, RhythmGame_Test_PC, TouchSwipe_Test_Mobile
}
